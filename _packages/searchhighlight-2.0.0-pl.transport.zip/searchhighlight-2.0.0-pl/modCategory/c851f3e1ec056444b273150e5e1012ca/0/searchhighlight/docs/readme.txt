SearchHighlight
===============

Highlight search terms on page linked from search results.

Based on the code of the MODX Evolution SearchHighlight Plugin.

If the URL of a page contains the request parameter 'searched', the value of this parameter is highlighted with a span inside of the body section (or <!--highlight_start--><!--highlight_end--> sections). The classname highlight span could be changed in MODX system settings in the 'searchhighlight' namespace.

To add a link to remove the highlighting and to show the search terms put the following on your page where you would like this to appear: <!--search_terms-->

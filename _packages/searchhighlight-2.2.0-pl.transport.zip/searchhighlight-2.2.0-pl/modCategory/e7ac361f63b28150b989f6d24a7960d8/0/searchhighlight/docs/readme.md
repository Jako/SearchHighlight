SearchHighlight
===============

- Authors: Thomas Jakobi <office@treehillstudio.com>
- License: GNU GPLv2

## Features

- Highlight search terms on page linked from search results.

## Installation

MODX Package Management

## Documentation

For more information please read the [documentation](https://jako.github.io/SearchHighlight/).

## GitHub Repository

https://github.com/Jako/SearchHighlight

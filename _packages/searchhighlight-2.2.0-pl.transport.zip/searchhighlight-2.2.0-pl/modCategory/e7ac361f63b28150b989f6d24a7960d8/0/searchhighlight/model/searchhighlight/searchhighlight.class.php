<?php
/**
 * SearchHighlight
 *
 * Copyright 2015-2022 by Thomas Jakobi <office@treehillstudio.com>
 *
 * @package searchhighlight
 * @subpackage classfile
 */

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

/**
 * Class SearchHighlight
 */
class SearchHighlight extends \TreehillStudio\SearchHighlight\SearchHighlight
{
}

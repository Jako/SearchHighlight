SearchHighlight
===============

- Authors: Thomas Jakobi <thomas.jakobi@partout.info>
- License: GNU GPLv2

## Features

- Highlight search terms on page linked from search results.

## Installation

MODX Package Management

## Documentation

The plugin highlights the searched terms in the `searched` request parameter on the fly on the current displayed page. If the request parameter `searchtype` is filled with `exactphrase`, only the full request in `searched` is highlighted. 

There is no othe documentation available at the moment, but you could change a lot of SearchHighlight options with the systemsettings in the `searchhighlight` namespace.

## GitHub Repository

https://github.com/Jako/SearchHighlight

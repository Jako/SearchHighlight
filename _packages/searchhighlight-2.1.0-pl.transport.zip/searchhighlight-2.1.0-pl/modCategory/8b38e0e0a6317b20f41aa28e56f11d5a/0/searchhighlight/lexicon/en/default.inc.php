<?php
/**
 * Default Lexicon Entries for SearchHighlight
 *
 * @package searchhighlight
 * @subpackage lexicon
 */
$_lang['searchhighlight.search_terms'] = 'Search Terms';
$_lang['searchhighlight.remove_highlighting'] = 'Remove Highlighting';
